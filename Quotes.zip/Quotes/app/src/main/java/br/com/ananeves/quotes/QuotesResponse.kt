package br.com.ananeves.quotes

class QuotesResponse {
    var text: String = ""
    var author: String = ""
}