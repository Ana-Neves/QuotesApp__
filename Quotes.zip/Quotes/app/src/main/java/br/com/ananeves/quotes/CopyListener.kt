package br.com.ananeves.quotes

interface CopyListener {
    fun onCopyClicked(text: String)
}